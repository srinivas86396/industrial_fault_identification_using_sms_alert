adc.o: ADC.c
adc.o: C:\KeilARM\ARM\INC\Philips\LPC214x.h
adc.o: types.h
adc.o: defines.h
adc.o: adc_defines.h
adc.o: delay.h
