delays.o: delays.c
