eint.o: EINT.C
eint.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
eint.o: defines.h
