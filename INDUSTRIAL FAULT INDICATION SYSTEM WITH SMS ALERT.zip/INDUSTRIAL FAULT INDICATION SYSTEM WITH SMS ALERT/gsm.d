gsm.o: gsm.c
gsm.o: C:\KeilARM\ARM\RV31\INC\string.h
gsm.o: uart0.h
gsm.o: delay.h
gsm.o: lcd.h
