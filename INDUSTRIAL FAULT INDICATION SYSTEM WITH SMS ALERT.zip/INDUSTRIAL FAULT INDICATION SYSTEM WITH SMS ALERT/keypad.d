keypad.o: keypad.c
keypad.o: C:\KeilARM\ARM\INC\Philips\LPC214x.h
keypad.o: C:\KeilARM\ARM\RV31\INC\stdlib.h
keypad.o: lcd.h
keypad.o: delay.h
