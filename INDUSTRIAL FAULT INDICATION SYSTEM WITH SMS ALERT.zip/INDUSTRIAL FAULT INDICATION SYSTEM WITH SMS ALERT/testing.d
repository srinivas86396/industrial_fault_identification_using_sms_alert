testing.o: testing.c
testing.o: C:\KeilARM\ARM\INC\Philips\LPC214X.H
testing.o: delays.h
