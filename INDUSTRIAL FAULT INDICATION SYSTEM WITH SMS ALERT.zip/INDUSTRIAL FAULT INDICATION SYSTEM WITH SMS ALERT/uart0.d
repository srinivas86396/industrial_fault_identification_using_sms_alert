uart0.o: uart0.c
uart0.o: C:\KeilARM\ARM\INC\Philips\LPC214x.H
uart0.o: C:\KeilARM\ARM\RV31\INC\string.h
uart0.o: delay.h
